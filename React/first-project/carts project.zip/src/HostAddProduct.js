import React from 'react';
import AddProduct from './AddProduct';
import Button from '@material-ui/core/Button';

const HostAddProduct = (props) => {
    if(props.addP){
        return <Button onClick={() =>props.setAddP(false)}>Add product</Button>
    }else{
        return <AddProduct setAddP={props.setAddP} addProduct={props.addProduct}></AddProduct>
    }
}

export default HostAddProduct;