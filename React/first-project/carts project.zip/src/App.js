import React, { useState } from 'react';
import './App.css';
import Header  from './Header';
import Host from './Host';

const App = () => {
  const [n,setN] = useState(true);
  return (
    <div className='App'><h1> My shop</h1>
      <div><Header setN={setN}/></div >
      <Host n={n}></Host>
  </div>
  );
}

export default App;