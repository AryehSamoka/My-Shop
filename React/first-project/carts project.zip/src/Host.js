import React, { useState } from 'react';
import Products, { initialProducts } from './Products';
import Cart from './Cart';
import HostAddProduct from './HostAddProduct';

const Host = (props) => {
  const [cartProducts, setCartProducts] = useState([]);
  const [products, setProducts] = useState(initialProducts)
  const [idProd, setIdProd] = useState(7);
  const [addP, setAddP] = useState(true);
  const includesId = (array, item) => {
    return array.map(element =>
      element.id === item.id).includes(true);
  };

  const addProduct = (item) => {
    setIdProd(idProd + 1);
    setProducts([...products, { id: idProd, ...item }])
  }

  const incrAmount = (array, item) => {
    array.forEach(
      e => {
        if (e.id === item.id) {
          e.amount = e.amount + 1;
        };
      });
    return array;
  };

  const addItem = (item) => {
    let array = [...cartProducts];
    if (includesId(array, item)) {
      setCartProducts([...incrAmount([...cartProducts], item)]);
    } else {
      setCartProducts([...cartProducts, { ...item, amount: 1 }]);
    }
  }

  const removeItem = (item) => {
    let index;
    cartProducts.forEach((el, ind) => {
      if (el.id === item.id) {
        index = ind;
      }
    });
    let tempCartProducts = [...cartProducts];
    tempCartProducts.splice(index, 1)
    setCartProducts(tempCartProducts);
  }

  if (props.n) {
    return (
      <div >
        <Products products={products} addItem={addItem}></Products>
        <HostAddProduct addProduct={addProduct} addP={addP} setAddP={setAddP}></HostAddProduct>
      </div>

    );
  } else {
    return (
      <div>
        <Cart removeItem={removeItem} products={cartProducts}></Cart>
      </div>);
  }
}

export default Host;